import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.cashierr12.com',
  appName: 'loyalty-cashier',
  webDir: 'www',
  server: {
    androidScheme: 'https'
  }
};

export default config;
