import { Component } from '@angular/core';
import { register } from 'swiper/element/bundle';
import { ApiService } from './services/api.service';
import { Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { StorageService } from 'src/app/services/storage.service';
import { Network } from '@capacitor/network';
import { MessageService } from './services/message.service';
import { constantKeys } from 'src/constant/constant';
import { StatusBar, Style } from '@capacitor/status-bar';

register();
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  business_data = "business_data";
  userdata = "user_data";
  businessData: any;
  businessinfo: any;
  backButton: any;
  constructor(private message: MessageService, private apiService: ApiService, private router: Router, private platform: Platform, private storageservice: StorageService,) {
    StatusBar.hide();
    const storedData = this.apiService.getLocalStorageData(this.business_data)
    this.businessData = JSON.parse(storedData);
    if(this.businessData){
      this.navigate();
    }
    else{
      this.router.navigate(['/business-id-page']);
    }
    console.log('this.businessDatafgshh===>', this.businessData)
     
    Network.addListener('networkStatusChange', status => {
      console.log('Network status changed', status);
      if (status.connected) {

      } else {
        this.message.presentToast('You Are Offline', 'danger');
      }
     });
  }
  ngOnDestroy() {
    this.platform.backButton.unsubscribe();
  }
  // ionViewDidEnter() {
  //   this.navigate();
  // }
  navigate() {
    const storedData = this.apiService.getLocalStorageData(this.business_data);
    this.businessData = JSON.parse(storedData);
    console.log('this.businessDatafgshh===>', this.businessData)
    if (this.businessData) {
      const storedData = this.apiService.getLocalStorageData(this.userdata);
      console.log('this.businessData======>', this.businessData.data.theme_color)
      const darkColor = this.ColorLuminance(this.businessData.data.theme_color, -0.5)
      console.log('darkColor====>', darkColor)
      const themeWrapper = document.querySelector('body');
      document.documentElement.style.setProperty('--secondary-color', darkColor || '#00308F');
      document.documentElement.style.setProperty('--primary-color', this.businessData.data?.theme_color || '#00308F');
      if (storedData) {
         this.storageservice.get(constantKeys.connectioninfo).then(data => {
          if (data) {
            let info = JSON.parse(data);
            if (info) {
              this.businessinfo = info;
              console.log("businessinfo", this.businessinfo)
              this.router.navigate(['/main-cashier-interface'])
              // this.router.navigate(['/testpage'])
            }
            else {
              console.log('FALSE')
            }
          } else {
            this.router.navigate(['/code-screen'])
          }
        });
        console.log('bussdhshhfgsdg why ')
        this.router.navigate(['/cashier-login'])
      }
      else {
        this.router.navigate(['/cashier-login']);
      }
    }
    else {
      console.log('business-id-page')
      this.router.navigate(['/business-id-page']);
     }
  
  }
  ColorLuminance(hex, lum) {
    hex = String(hex).replace(/[^0-9a-f]/gi, '');
    if (hex.length < 6) {
      hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
    }
    lum = lum || 0;
    var rgb = "#", c, i;
    for (i = 0; i < 3; i++) {
      c = parseInt(hex.substr(i * 2, 2), 16);
      c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
      rgb += ("00" + c).substr(c.length);
    }
    return rgb;
  }

}



