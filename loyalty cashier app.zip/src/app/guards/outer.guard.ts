import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OuterGuard implements CanActivate {
  userData: any;
  business_data: string;
  constructor(private router: Router) { 
       this.business_data=localStorage.getItem('business_data');
  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      if(!this.business_data){
        console.log('real outer auth if');
          return true;
        }else{
          console.log("real outer auth else ");
          // this.router.navigateByUrl('/cashier-login');
          return true;
      }
  }
}
