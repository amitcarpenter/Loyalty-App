import { Component, OnInit,ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { IonInput, Platform } from '@ionic/angular';
import { ApiService } from 'src/app/services/api.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MessageService } from 'src/app/services/message.service';

@Component({
  selector: 'app-business-id-page',
  templateUrl: './business-id-page.page.html',
  styleUrls: ['./business-id-page.page.scss'],
})
export class BusinessIdPagePage implements OnInit {
  @ViewChild('emailInput', { static: true }) emailInput: IonInput;
  businessId: string = '';
  backButton: any;
  constructor(private router: Router, private apiService: ApiService, private loader: LoaderService,
    private message: MessageService,
    private platform: Platform
  ) { }

  ngOnInit() {
  }
  addToBusinessId(value: any) {
    this.businessId += value;
  }
  removeLastDigit() {
    this.businessId = this.businessId.slice(0, -1);
  }
  submitBusinessId() {

    if (!this.businessId.trim()) {
      this.message.presentToast('Enter Business Id', 'danger');
      return;
    }
    const data = {
      business_id: this.businessId
    }
    this.loader.show();
    try {
        this.apiService.getBusinessId(data).subscribe(res => {
        this.loader.dismiss();
        console.log('business_data', res)
        localStorage.setItem('business_data', JSON.stringify(res));
        this.loader.dismiss();
        this.router.navigate(['/cashier-login']);
        this.message.presentToast('Connect with business', 'success');
        }, (error) => {
        this.loader.dismiss();
        this.message.presentToast('Something went wrong', 'danger');
      })
    } catch (err) {
      this.loader.dismiss();
      console.log('we getting some error');
    }
   }
   ionViewDidEnter() {
    this.emailInput.setFocus();
    console.log('this.emailInput.setFocus();', this.emailInput)
    this.backButton = this.platform.backButton.subscribeWithPriority(9999, () => {
    });
  }
    ionViewWillLeave() {
      this.loader.dismiss();
      this.backButton.unsubscribe();
    }
}
