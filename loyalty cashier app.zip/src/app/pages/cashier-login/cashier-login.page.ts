import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { ApiService } from 'src/app/services/api.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MessageService } from 'src/app/services/message.service';
import { environment } from 'src/environments/environment';
import { IonInput } from '@ionic/angular';
import { Keyboard } from '@capacitor/keyboard';
import { AlertController } from '@ionic/angular';


@Component({
  selector: 'app-cashier-login',
  templateUrl: './cashier-login.page.html',
  styleUrls: ['./cashier-login.page.scss'],
})
export class CashierLoginPage implements OnInit {
  @ViewChild('emailInput', { static: true }) emailInput: IonInput;

  business_data = "business_data";
  businessData: any;
  email: any;
  password: any;
  environment = environment;
  backButton: any;
  constructor(private alertController: AlertController,private router: Router, private apiService: ApiService, private loader: LoaderService,private platform: Platform,
    private message: MessageService,) {
    
    this.apiService.setTheme();
    Keyboard.show();
    const storedData = this.apiService.getLocalStorageData(this.business_data);
    if (storedData) {
      this.businessData = JSON.parse(storedData);
      document.documentElement.style.setProperty('--primary-color', this.businessData.data?.theme_color || '#00308F');
      console.log('this.businessData======>', this.businessData)
    }
  }
  ngOnInit() {
    this.emailInput.setFocus();
   }
  onSubmit() {
    if (!this.email || !this.password) {
      this.message.presentToast('All fields are required', 'danger');
      return;
    }
    const data = {
      email: this.email,
      password: this.password,
      organization_id:this.businessData.data.id.toString()
    };
    console.log('data', data);
    console.log('Business ID submitted:', this.email);
    this.loader.show();
    this.apiService.login(data).subscribe(
      (res) => {
        console.log('Response:', res);
        localStorage.setItem('user_data', JSON.stringify(res));
        this.loader.dismiss();
        this.router.navigate(['/code-screen']);
        this.email = '';
        this.password = '';
      },
      (error) => {
        console.error('Error during login:', error);
        let errorMessage = 'An error occurred';
        this.loader.dismiss();
        if (error && error.error && error.error.message) {
          errorMessage = error.error.message;
        } else if (error && error.message) {
          errorMessage = error.message;
        }
        this.message.presentToast(errorMessage, 'danger');
      }
    );
  }
  ionViewDidEnter() {
    this.emailInput.setFocus();
    this.backButton = this.platform.backButton.subscribeWithPriority(9999, () => {
     });
    }
    ionViewWillLeave() {
      this.loader.dismiss();
      this.backButton.unsubscribe();
    }
}
