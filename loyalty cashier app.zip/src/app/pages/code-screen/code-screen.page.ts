import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { StorageService } from 'src/app/services/storage.service';
import { constantKeys } from 'src/constant/constant';
import { environment } from 'src/environments/environment';
import { IonInput, Platform } from '@ionic/angular';
import { Keyboard } from '@capacitor/keyboard';
import { MessageService } from 'src/app/services/message.service';
import { SocketIoService } from 'src/app/services/socket-io.service';
@Component({
  selector: 'app-code-screen',
  templateUrl: './code-screen.page.html',
  styleUrls: ['./code-screen.page.scss'],
})
export class CodeScreenPage implements OnInit {
  @ViewChild('emailInput', { static: true }) emailInput: IonInput;
  clicked = false;
  clickedStates: boolean[] = Array(10).fill(false);
  number: string = '';
  userData: any;
  business_data = "business_data";
  businessData: any;
  Unique_code: string = '';
  businessinfo: any
  resBussnessData: any;
  environment = environment;
  backButton: any;
  constructor(private SocketIoService: SocketIoService, private massgageservice: MessageService, private router: Router, private apiService: ApiService, private storageservice: StorageService, private platform: Platform) {
    console.log('this.Unique_code=====>', this.Unique_code)
    this.apiService.setTheme();
    Keyboard.hide();
    const storedData = this.apiService.getLocalStorageData(this.business_data);
    this.businessData = JSON.parse(storedData);
    console.log('this.businessData======>', this.businessData)
    this.getStorageinfo();
    }
  ngOnInit() {
    const storedData = localStorage.getItem('user_data');
    const userData = JSON.parse(storedData);
    console.log('userData', userData);
    if (userData) {
      this.userData = userData;
    }
  }
  navigatewellcome() {
    this.router.navigate(['/connection-successful'])
  }
  addToBusinessId(value: any) {
    this.clickedStates[value] = !this.clickedStates[value];
    setTimeout(() => {
      this.clickedStates[value] = !this.clickedStates[value];
    }, 300)
    console.log('this.clicked=true;===>', this.clicked = true);
    if ((this.Unique_code + value).length <= 4) {
      this.Unique_code += value;
    } else {
      this.massgageservice.presentToast('You can Enter only 4 Digit', 'danger')
    }
  }
  removeLastDigit() {
    this.Unique_code = this.Unique_code.slice(0, -1);
  }
  submitUnique_code() {
    // this.SocketIoService.offevent(`connection_ready_${this.Unique_code}`)
    let info = {
      org_id: this.businessData.data.id,
      unique: this.Unique_code,
      cashier_id: this.userData.data.id
    }
    const cashierConnection = 'cashierConnection';
    this.SocketIoService.sendSocketMessage(cashierConnection, info)
    this.resBussnessData?.unsubscribe();
    this.SocketIoService.receiveBussnessResponse(`receive_Bussness_Response${this.Unique_code}`)
    this.resBussnessData = this.SocketIoService.receiveBussnessResponse$.subscribe(
      (res: any) => {
        let r_res = res
        console.log('r_res===>1212', r_res)
        if (r_res) {
          console.log('Connection successfully receive_Bussness_Response', r_res);
          if (res.status == 1) {
            r_res = JSON.stringify(r_res);
            this.storageservice.set(constantKeys.connectioninfo, r_res)
            this.navigatewellcome();
          } else if (res.ms == 'Not Found') {
            this.massgageservice.presentToast("Incorrect Code", "danger", "top")
            console.log('CODE NOT FOUND.............');
          }
        }
      }, (err) => {
        this.massgageservice.presentToast("Incorrect Code", "danger", "top")
      })
  }
  getStorageinfo() {
    this.storageservice.get(constantKeys.businessInfo).then(data => {
      if (data) {
        let info = JSON.parse(data);
        if (info) {
          this.businessinfo = info;
          console.log("businessinfo", this.businessinfo)
          console.log('TRUE')
        } else {
          console.log('FALSE')
        }
      }
    });
  }
  ionViewDidEnter() {
    this.emailInput.setFocus();
    Keyboard.hide();
    this.backButton = this.platform.backButton.subscribeWithPriority(9999, () => {
    });
  }
  ionViewWillLeave() {
    // this.loader.dismiss();
    // this.SocketIoService.receiveBussnessResponse$?.unsubscribe();
    this.backButton.unsubscribe();
    // if(this.SocketIoService.receiveBussnessResponse$){
    //   this.SocketIoService.receiveBussnessResponse$?.unsubscribe();
    //   console.log('helllo abhi how are you leave this page2',this.resBussnessData);
    // }
  }
  ngOnDestroy() {
    console.log('helllo abhi how are you leave this page1', this.resBussnessData);
  }
}
