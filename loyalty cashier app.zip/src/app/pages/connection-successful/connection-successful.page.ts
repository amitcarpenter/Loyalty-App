import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-connection-successful',
  templateUrl: './connection-successful.page.html',
  styleUrls: ['./connection-successful.page.scss'],
})
export class ConnectionSuccessfulPage implements OnInit {
  environment=environment;
 constructor(
    private router:Router,
    private platform: Platform
  ) { 
   setTimeout(() => {
      this.router.navigate(['/main-cashier-interface'])
    },2000);
   }
   ngOnInit() {
  }
}
