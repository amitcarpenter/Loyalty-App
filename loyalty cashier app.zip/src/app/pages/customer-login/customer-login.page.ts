import { Component, OnInit } from '@angular/core';
import { Router ,ActivatedRoute} from '@angular/router';
import { Platform } from '@ionic/angular';
import { ApiService } from 'src/app/services/api.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MessageService } from 'src/app/services/message.service';
import { constantKeys } from 'src/constant/constant';
import { environment } from 'src/environments/environment';
import { Keyboard } from '@capacitor/keyboard';

@Component({
  selector: 'app-customer-login',
  templateUrl: './customer-login.page.html',
  styleUrls: ['./customer-login.page.scss'],
})

export class CustomerLoginPage implements OnInit {
  clickedStates: boolean[] = Array(12).fill(false);
  number: string = '';
  businessData: any;
  business_data = "business_data"
  organization_id: string = '';
  loginType:string;
  environment = environment;
  constructor(
    private router: Router,
    private apiService: ApiService,
    private loader: LoaderService,
    private message: MessageService,
    private ActiveRoute: ActivatedRoute,
    private platform: Platform
    ) {
    this.apiService.setTheme();
    Keyboard.hide();
    const storedData = this.apiService.getLocalStorageData(this.business_data);
    this.businessData = JSON.parse(storedData);
    this.organization_id = this.businessData.data.id
  }

  ngOnInit() {
    this.ActiveRoute.paramMap.subscribe(params => {
      this.loginType=params.get('type');
      console.log('loginType',this.loginType);
    });
  }
  navigatewellcome() {
    this.router.navigate(['/welcome-screen'])
  }
  addToBusinessId(value: any) {
    this.clickedStates[value] = !this.clickedStates[value];
    setTimeout(()=>{
      this.clickedStates[value] = !this.clickedStates[value];
    },300)
    
    if ((this.number + value).length <= 10) {
      this.number += value; 
     }else{
      this.message.presentToast('Please Enter 10 Digit','danger')
     }
  }
  removeLastDigit() {
    
    this.number = this.number.slice(0, -1);
  }
  
  submit() {
    if (!this.number) {
      this.message.presentToast('All fields are required', 'danger');
    } 
    if ((this.number).length <10) {
      this.message.presentToast('Please Enter 10 Degit','danger')
      return
   }
    else {
  
    const data = {
      contact_number: this.number,
      organization_id: this.organization_id.toString()
    }
    this.loader.show();
    console.log('Business ID submitted:', this.number);
    try {
      this.apiService.customerLogin(data).subscribe((res: any) => {
        console.log('ressssss=>', res)
        this.loader.dismiss();
        if (res.data.userType == 'NEW') {
          localStorage.setItem(constantKeys.onCall,'true');
          localStorage.setItem(constantKeys.customerProfileinfo, JSON.stringify(res.data));
          this.loader.dismiss();
          this.router.navigate(['/customer-signup/OnCall'], { queryParams: { number: this.number } });
        } else if(res.data.userType == 'OLD'){
          localStorage.setItem(constantKeys.customerProfileinfo, JSON.stringify(res.data));
          localStorage.setItem(constantKeys.onCall,'true');
          this.loader.dismiss();
          this.router.navigate(['/welcome-screen'])
        }
      },(error) => {
          if (error) {
            this.loader.dismiss();
            this.message.presentToast("Something Went Wrong", 'danger');
           } 
        }
      )
    }
    catch (err) {
      this.loader.dismiss();
      console.log('we getting some error');
    }
  }
 }
}


