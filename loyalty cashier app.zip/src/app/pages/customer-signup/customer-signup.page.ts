import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MessageService } from 'src/app/services/message.service';
import { ActivatedRoute } from '@angular/router';
import { constantKeys } from 'src/constant/constant';
import { environment } from 'src/environments/environment';
import { IonModal, Platform } from '@ionic/angular';
import { IonInput } from '@ionic/angular';
import { IonDatetime } from '@ionic/angular';
import * as moment from 'moment';
@Component({
  selector: 'app-customer-signup',
  templateUrl: './customer-signup.page.html',
  styleUrls: ['./customer-signup.page.scss'],
})
export class CustomerSignupPage implements OnInit {
  @ViewChild('emailInput', { static: true }) emailInput: IonInput;
  @ViewChild(IonModal) modal: IonModal;
  @Input() public displayFormat: string = 'DD/MM/YYYY';
  @Input() public date: string;
  public isModalOpen = false;
  public onTouched: () => void;
  public propagateChange: (_: any) => void;
  business_data = "business_data";
  businessData: any;
  name: any;
  number: any;
  organization_id: any;
  environment = environment;
  backButton: any;
  username: any;
  constructor(private apiService: ApiService, private fb: FormBuilder, private router: Router,
    private loader: LoaderService,
    private route: ActivatedRoute,
    private message: MessageService,
    private platform: Platform,


  ) {
    const storedData = this.apiService.getLocalStorageData(this.business_data);
    this.businessData = JSON.parse(storedData);
    this.organization_id = this.businessData.data.id
  }
  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.number = params['number'];
      console.log(this.number);
    });
  }
  onInputChange(event: any) {
    if (event && event.key === "Enter") {  
      event.preventDefault(); 
      this.onSubmit(); 
    }
  }
  onSubmit() {
    if (!this.name) {
      this.message.presentToast('Name is required', 'danger');
    } else {
      this.username = this.name.split(' ');
      for (let i = 0; i < this.username.length; i++) {
        this.username[i] = this.username[i].charAt(0).toUpperCase() + this.username[i].slice(1);
      }
      let capitalizedString = this.username.join(' ');
      this.loader.show();

      try {

        var dateObject = new Date(this.date);
        var day = dateObject.getDate();
        var month = dateObject.getMonth() + 1;
        var year = dateObject.getFullYear();
        const dob = `${day}/${month}/${year}`;
        const data = {
          username: capitalizedString,
          dob: dob,
          contact_number: this.number,
          organization_id: this.organization_id.toString()
        };
        console.log('data=====>,', data);
        this.apiService.signup(data).subscribe((res: any) => {
          this.loader.dismiss();
          console.log('ressssss=>Sign up', res);

          localStorage.setItem(constantKeys.customerProfileinfo, JSON.stringify(res.data));
          this.router.navigate(['/welcome-screen']);
          this.name = "";
          this.date = "";
          this.loader.dismiss();
        }, (error) => {
          this.loader.dismiss();
          console.error('Error during signup:', error);
          this.message.presentToast('Something went wrong', 'danger');
        });
      } catch (err) {
        this.loader.dismiss();
        console.error('An unexpected error occurred:', err);
        this.message.presentToast('Something went wrong', 'danger');
      }
    }
  }
  getMinDate(): string {
    const today = new Date();
    const minDate = today.toISOString().substr(0, 10);
    return minDate;
  }
  ionViewDidEnter() {
    this.emailInput.setFocus();
    this.backButton = this.platform.backButton.subscribeWithPriority(9999, () => {
    });
  }
  ionViewWillLeave() {
    this.backButton.unsubscribe();
  }
  public get dateValue() {
    console.log('date ==>', this.date)
    return this.date;
  }

  public set dateValue(val: string) {
    this.date = moment(val).format('YYYY-MM-DD');
    console.log('dateValue==>', this.date)
    this.propagateChange(this.date);
  }

  public writeValue(value: any) {
    if (value !== undefined) {
      this.date = value;
    }
  }

  public registerOnChange(fn) {
    this.propagateChange = fn;
  }

  public registerOnTouched(fn) {
    this.onTouched = fn;
  }

  public openModal() {
    this.isModalOpen = true;
  }

  public handleDismiss() {
    this.isModalOpen = false;
  }

  /**
   * Returns a string formatted in the component's display format
   *
   * @param date the date to format
   */
  public getFormattedDateDisplay(date: string): string {

    if (!date) {
      return '';
    }

    return moment(date).format(this.displayFormat);
  }
}
