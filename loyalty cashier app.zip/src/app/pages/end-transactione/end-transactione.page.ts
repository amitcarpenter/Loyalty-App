import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { SocketIoService } from 'src/app/services/socket-io.service';
@Component({
  selector: 'app-end-transactione',
  templateUrl: './end-transactione.page.html',
  styleUrls: ['./end-transactione.page.scss'],
})
export class EndTransactionePage implements OnInit {

  constructor(private router:Router,private platform: Platform,private SocketIoService:SocketIoService ) { 
    // this.SocketIoService.receiveBussnessData$.next('Empty');
    
    console.log('Hello abhi how are you beta')
    setTimeout(() => {
      this.router.navigate(['/main-cashier-interface'])
      // location.reload();
    }, 3000);
  }

  ngOnInit() {
  }

}
