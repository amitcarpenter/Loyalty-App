import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { Swiper } from 'swiper';
import { StorageService } from 'src/app/services/storage.service';
import { constantKeys } from 'src/constant/constant';
import { AlertController } from '@ionic/angular';
import { environment } from 'src/environments/environment';
import { ToastController } from '@ionic/angular';
import { Keyboard } from '@capacitor/keyboard';
import { MessageService } from 'src/app/services/message.service';
import { debounceTime } from 'rxjs/operators';
import { consumerPollProducersForChange } from '@angular/core/primitives/signals';
import { LoaderService } from 'src/app/services/loader.service';
import { Subject } from 'rxjs';
@Component({
  selector: 'app-main-cashier-interface',
  templateUrl: './main-cashier-interface.page.html',
  styleUrls: ['./main-cashier-interface.page.scss'],
})
export class MainCashierInterfacePage implements OnInit {
  noUser = false;
  count=0;
  Waiting = false;
  amount:any;
  loyaltypoints: any
  timer: any;
  OnCall: boolean = false;
  OnCallMs: boolean = true;
  handlerMessage = '';
  roleMessage = '';
  orderNotConfirms = 'Order Not Confirm By the '
  connectioninfo: any;
  private socket: any;
  public message: string = '';
  @ViewChild('swiper')
  swiperRef: ElementRef | undefined;
  cancle_btn = true;
  user_data = "user_data";
  business_dataname= "business_data";
  businessData: any;
  clientInfo: any;
  rewardinfo: any;
  bussnessId: any = "";
  selectedOffer: any;
  selectedOfferData: any;
  environment = environment;
  availableUser: boolean = true;
  confirmItem:boolean=true;
  sendBussnessId='sendBussnessId';
  endtransaction='endtransaction';
  sendBussnessResponse='sendBussnessResponse';
  resBussnessData:any;
  swiper = new Swiper('.swiper-container', {
    slidesPerView: 2,
    breakpoints: {
      900: {
        slidesPerView: 2,
      },
      1200: {
        slidesPerView: 4,
      },

    },

  });
  loyalty_businessData: any;
  private amountSubject = new Subject<number>();
  constructor(private router: Router,
    private apiService: ApiService,
    private storageservice: StorageService,
    private alertController: AlertController,
    private activeroute: ActivatedRoute,
    private toastController: ToastController,
    private messageService: MessageService,
    private loader:LoaderService
    
  ) {
    const business_data = this.apiService.getLocalStorageData(this.business_dataname);
    this.loyalty_businessData = JSON.parse(business_data);
    console.log('this.businessData helllo   usmy abhi======>',this.loyalty_businessData)
    this.apiService.setTheme();
    this.amountSubject.pipe(
      debounceTime(1000) 
    ).subscribe(amount => {
      this.getLoyaltyPointsFun(amount);
    });
   }
  swiperSlideChanged(e: any) {
    console.log('changed: ', e);
  }
  swiperReady() {
    this.swiper = this.swiperRef?.nativeElement.swiper;
   }
   goNext() {
     this.swiper?.slideNext();
  }
  goPrev() {
    console.log(' this.swiper====>', this.swiper)
    this.swiper?.slidePrev();
  }
   ionViewWillLeave() {
     console.log('helllo abhi how are you leave this page1',this.resBussnessData);
   
    console.log('helllo abhi how are you leave this page2',this.resBussnessData);
   }

  ngOnInit() {
    this.amount=null;
    this.noUser = true;
    this.availableUser = false;
    const storedData = this.apiService.getLocalStorageData(this.user_data);
    this.businessData = JSON.parse(storedData);
    this.getStorageinfo();
    
    this.GetOrderOnCallInfoFun();
    console.log('ng onit data ',this.clientInfo)
    if (this.connectioninfo && this.connectioninfo.org_id) {
      this.getRewardFun(this.connectioninfo.org_id);
    }
  }
  ionViewWillEnter() {
    console.log(' ionViewWillEnter====>',this.clientInfo)
     this.activeroute.url.subscribe(url => {
      this.amount=null;
      this.noUser = true;
      this.selectedOffer=' ';
      this.availableUser = false;
      this.GetOrderOnCallInfoFun();
    });
  }
  getStorageinfo() {
      this.storageservice.get(constantKeys.connectioninfo).then(data => {
      if (data) {
        console.log(data);
        let info = JSON.parse(data);
        if (info) {
          this.connectioninfo = info;
          this.bussnessId = info.code
          if (this.connectioninfo && this.connectioninfo.org_id) {
            this.getRewardFun(this.connectioninfo.org_id);
          }
        
    
        } else {
          this.router.navigate(['/code-screen'])
        }
      } else {
        this.router.navigate(['/code-screen'])
      }
    });
  }
  getuserinfoFun(data: any) {
  // this.loader.show();
    this.apiService.getuserinfo(data).subscribe((userinfo: any) => {
      // this.loader.dismiss();
      if (userinfo && userinfo.data) {
        this.ShowDataFun(false, true); 
        if (this.OnCall) {
           return
        }
        this.clientInfo = userinfo.data;
        console.log('this.clientInfo=====>',this.clientInfo)
      } else {
        this.ShowDataFun(true, false);
      }
    }, (error => {
      // this.loader.dismiss();
       console.log('error', error)
    }))
  }
  logOut() {
    let instruction = {
      endtransaction: true,
      bussnessId: this.connectioninfo.code,
      cashierLogout: true,
      ms:'cashier Logout the screen'
    }
    console.log('this.connectioninfo.code===>',instruction)
    localStorage.removeItem(constantKeys.customerProfileinfo);
    localStorage.removeItem('user_data');
    localStorage.removeItem(constantKeys.onCall);
    this.storageservice.removeData(constantKeys.userinfo);
    this.router.navigate(['/cashier-login']);
    this.clientInfo=[];
    this.storageservice.removeData(constantKeys.connectioninfo);
  }
 logout:boolean=false

exitSession(): Promise<string> {
  return new Promise((resolve, reject) => {
      this.logout = true;
      this.noUser = true;
      this.availableUser = false;
      this.amount = null;
      const instruction = {
        endtransaction: true,
        bussnessId: this.connectioninfo.code
      };
      if (!this.OnCall) {
      
      }
      this.clientInfo = [];
      this.disconectOnCall();
      resolve("Session exited successfully."); 
    
  });
}
  getRewardFun(id: any) {
    let data = {
      'organization_id': id
    }
    this.apiService.getReward(data).subscribe((reward: any) => {
      if (reward && reward.data) {
        this.rewardinfo = reward.data;
      } else {
      }
    }, (error => {
      console.log('error', error);
    }))
  }
  abc(event: any) {

    return event.preventDefault();
    
  }
  onInputChange(event: any) {
    const inputValue = event.target.value ?? 0;
    if (event && event.key === "Enter") {  
      event.preventDefault(); 
      this.hideKeyboard(); 
      return;
   }
   if (this.amount >= 0 || this.amount == 0) {
       this.amountSubject.next(inputValue)
      }
   }
  getLoyaltyPointsFun(amount: number) {
    // this.loader.show();\
    if(!amount){
        console.log('no have value')
        amount=0;
    }
    let data = {
      "transaction_amount": amount,
      "customer_id": this.clientInfo.id,
      "organization_id": this.connectioninfo.org_id
    }
       if(!data){
        return
       }
      this.apiService.getLoyaltyPoints(data).subscribe((points: any) => {
      // this.loader.dismiss();
      console.log('you got loyalty point 4',points.data.loyalty_point)
      if (points && points.data) {
        this.loyaltypoints = `${points.data && points.data.LoyaltyPoints && points.data.LoyaltyPoints > 0 ? points.data.LoyaltyPoints : 0}`
        let instruction = {
          endtransaction: false,
          bussnessId: this.connectioninfo.code,
          loyaltypoints: this.loyaltypoints
        }
        if (!this.OnCall) {
          
        }
      }
    }, (error) => {
      // this.loader.dismiss();
      console.log('error in getLoyaltyPointsFun', error);
    })
  }
  submitOrderFun() {
      let instruction = {
      endtransaction: true,
      bussnessId: this.connectioninfo.code
    }
    if (this.amount >=0 || this.amount == 0)  {
      if(!this.clientInfo.confimReedum && !this.clientInfo?.total_loyalty_point || this.clientInfo?.total_loyalty_point==0)
      {
        this.clientInfo.confimReedum=true;
      }
      console.log('   this.clientInfo.confimReedum====>', this.clientInfo.confimReedum)
    let data = {
        "transaction_amount": this.amount ?? 0,
        "customer_id": this.clientInfo.id,
        "organization_id": this.connectioninfo.org_id,
        "customerVisitId": this.clientInfo.Customer_Visits[this.clientInfo.Customer_Visits.length - 1].id,
      }
      if (this.clientInfo)
      { 
        console.log('getRedeemLoyaltyPoints called')
        this.apiService.getRedeemLoyaltyPoints(data).subscribe(async (info: any) => {
        console.log('getRedeemLoyaltyPoints called',this.clientInfo)
          if (info && info.data) {
              if (this.clientInfo.total_loyalty_point && this.clientInfo.total_loyalty_point != 0 && this.selectedOfferData &&(this.selectedOfferData.loyalty_point <= this.clientInfo.total_loyalty_point) && this.selectedOffer && this.confirmItem) {
                  console.log('hello abhi run1') 
                  await this.redeemRewardFun();
                  console.log('hello abhi run2')  
               } else {
                this.loyaltypoints = 0;
              
                console.log('Else Total points', this.clientInfo?.total_loyalty_point)
               }
          
            this.exitSession();
           
            
          }
        }, error => {
          if (this.clientInfo?.total_loyalty_point && this.clientInfo?.total_loyalty_point != 0 && this.selectedOfferData.loyalty_point < this.clientInfo.total_loyalty_point && this.selectedOffer) {
            this.redeemRewardFun();
            console.log('Total points', this.clientInfo?.total_loyalty_point)  //remove the points from user account
          } else {
            console.log('Else Total points', this.clientInfo?.total_loyalty_point)
          }
          console.log('error in getRedeemLoyaltyPoints', error)
        })
      } else {
        if (!this.clientInfo.confimReedum) {
          if (this.clientInfo?.total_loyalty_point && this.clientInfo?.total_loyalty_point != 0 && this.selectedOfferData && this.selectedOfferData.loyalty_point < this.clientInfo.total_loyalty_point && this.selectedOffer) {
            this.messageService.presentToast(this.orderNotConfirms + ` ${this.clientInfo.name}`, 'danger', 'top')
          }
          return
        }
       
        this.exitSession();
        this.router.navigateByUrl('/end-transactione');
      }
    } else {
      this.messageService.presentToast('Please Enter Amount', 'danger', 'top')
      console.log('Amount is EMPTY', this.amount);
    }
  }

  GetOrderOnCallInfoFun() {
    this.amount=null;
    console.log('hello abhi verma this is your customer');
    const OnCall = this.apiService.getLocalStorageData(constantKeys.onCall);
    const customerProfileinfo: any = this.apiService.getLocalStorageData(constantKeys.customerProfileinfo);
      console.log('On Call', OnCall)
      if (OnCall) {
      this.OnCall = true;
      this.selectedOffer=''
      console.log('customerProfileinfo', JSON.parse(customerProfileinfo));
      let data = JSON.parse(customerProfileinfo)
      if (data) {
         this.clientInfo = data.customerDetails;
        // this.clientInfo.confimReedum;
        this.clientInfo.confimReedum = true;
       }
        this.ShowDataFun(false, true); //this.noUser=false;this.availableUser=true;
      } else {
       this.ShowDataFun(true, false); //this.noUser=true;this.availableUser=false; 
      this.OnCall = false;
    }
    // console.log('On customerProfileinfo',customerProfileinfo)
  }
  ShowDataFun(noUser: boolean, availableUser: boolean) {
    this.noUser = noUser;
    this.availableUser = availableUser;
  }

  selectOffer(i: any) {
    if (this.OnCall) {
      console.log("selected offer id", i)
      this.selectedOffer = i.id;
      if (this.selectedOffer && this.rewardinfo) {
        this.selectedOfferData = this.rewardinfo.find(item => item.id === this.selectedOffer)
        if (this.selectedOffer && this.selectedOfferData?.loyalty_point > this.clientInfo?.total_loyalty_point) {
          this.messageService.presentToast('Customer does not have enough loyalty points to redeem this reward', 'danger', 'top')
        }

      }
    }
  }
  // resetSelection
  resetSelectionFun() {
    this.clientInfo.confimReedum = false;
    this.confirmItem=false;
    console.log('resetSelectionFun Called...')
    this.selectedOffer = 0;
    let instruction = {
      endtransaction: false,
      bussnessId: this.connectioninfo.code,
      resetselection: true
    }

  }
  disconectOnCall() {
    this.OnCall = false;
    localStorage.removeItem(constantKeys.onCall);
    localStorage.removeItem(constantKeys.customerProfileinfo);
    this.clientInfo = [];
    this.router.navigateByUrl('/end-transactione');
    // location.reload();
  }
  async presentAlert(userId: any, selection: number) {
    const alert = await this.alertController.create({
      header: 'Customer Side Intraction! Cencel will give you 1 min to stop the user Instraction message',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            this.handlerMessage = 'Alert canceled';
            clearTimeout(this.timer);
            this.OnCallMs = false;
            this.timer = setTimeout(() => {
              this.OnCallMs = true;
            }, 60000);
          },
        },
        {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            this.OnCallMs = true;
            this.disconectOnCall();
            // get coming user data 
            if (userId) {
              let data = {
                userId: userId,
                organization_id:this.loyalty_businessData.data.id
                }
              if (selection) {
                this.selectedOffer = selection;
              }
              if(!this.logout)
              {
                this.getuserinfoFun(data)
              }
            }
            this.handlerMessage = 'Alert confirmed';
          },
        },
      ],
    });

    await alert.present();
    const { role } = await alert.onDidDismiss();
    this.roleMessage = `Dismissed with role: ${role}`;
  }
  redeemRewardFun() {
    if (!this.selectedOffer || this.selectedOffer == 0) {
      return
    }
    console.log('selectedOffer', this.selectedOffer);
    let input = {
      "reward_id": this.selectedOffer,
      "customer_id": this.clientInfo.id,
      "organization_id":this.loyalty_businessData.data.id,
      "customerVisitId": this.clientInfo.Customer_Visits[this.clientInfo.Customer_Visits.length - 1].id,
    }
    this.apiService.redeemReward(input).subscribe((redeem: any) => {
    console.log('redeem', redeem); //jk47
      let info = {
        bussnessId: this.bussnessId,
        item: this.selectedOffer,
        userId: `${this.clientInfo && this.clientInfo.id ? this.clientInfo.id : ''}`,
      }
      this.loyaltypoints = 0;
      return;
    }, (error) => {
      console.log('error', error)
    })
    // this.router.navigateByUrl('/transaction-end');
  }
  

  hideKeyboard() {
    console.log('Keyboard.hide();=====>', Keyboard.hide());
    Keyboard.hide();
   }
    
}
