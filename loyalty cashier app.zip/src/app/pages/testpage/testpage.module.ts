import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TestpagePageRoutingModule } from './testpage-routing.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TestpagePage } from './testpage.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TestpagePageRoutingModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  declarations: [TestpagePage]
})
export class TestpagePageModule {}
