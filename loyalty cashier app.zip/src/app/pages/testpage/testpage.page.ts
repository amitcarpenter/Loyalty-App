import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Swiper } from 'swiper';
@Component({
  selector: 'app-testpage',
  templateUrl: './testpage.page.html',
  styleUrls: ['./testpage.page.scss'],
})
export class TestpagePage implements OnInit {
  @ViewChild('swiper')
  swiperRef: ElementRef | undefined;
  swiper?: Swiper;
  slides: any[] = [1, 2, 3, 4, 5, 6];
  currentIndex: number = 0;

  items: number[] = [1, 2, 3, 4, 5, 6];
  constructor() {
  
  }

  ngOnInit() {
  }
  swiperSlideChanged(e: any) {
    // this.currentIndex++;
    // console.log('this.currentIndex1====>',this.currentIndex)
    // console.log('this.this.slides.length====>',this.slides.length)
    // if (this.currentIndex >= this.slides.length) {
    //   console.log('this.3====>',this.currentIndex)
    //    this.currentIndex = 0;
    // }
    // console.log('this.4====>',this.currentIndex)
    // this.slides.push(this.slides[this.currentIndex]);
   }
   // Reset swiper to the first slide when it reaches the end
  resetSwiper() {
    this.swiper.slideTo(0, 0);
  }

  swiperReady() {
    this.swiper = this.swiperRef?.nativeElement.swiper;
    console.log(' this.swiper====>', this.swiper)
  }

  goNext() {
    console.log(' this.swiper====>', this.swiper)
    this.swiper?.slideNext();
    if (this.swiper && this.swiper.activeIndex === this.swiper.slides.length - 2) {
      this.swiper.slideTo(0);
    }
  
  }

  goPrev() {
    console.log(' this.swiper====>', this.swiper)
    this.swiper?.slidePrev();
  }
}
