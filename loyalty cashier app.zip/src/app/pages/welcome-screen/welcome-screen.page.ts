import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-welcome-screen',
  templateUrl: './welcome-screen.page.html',
  styleUrls: ['./welcome-screen.page.scss'],
})
export class WelcomeScreenPage implements OnInit {
  businessData: any;
  business_data="business_data";
  backButton: any;

  constructor(private router:Router,private apiService:ApiService,private platform: Platform) { 
     setTimeout(()=>{
        this.router.navigate(['/main-cashier-interface']);
        // this.router.navigate(['/main-cashier-interface']);
      },2000)
    const storedData =this.apiService.getLocalStorageData(this.business_data);
    this.businessData = JSON.parse(storedData);
    console.log('this.businessData======>',this.businessData)
   }
   ngOnInit() {
  }
  ionViewDidEnter() {
 
    this.backButton = this.platform.backButton.subscribeWithPriority(9999, () => {
      
      });
    }
    ionViewWillLeave() {
      this.backButton.unsubscribe();
    }
}
