import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'phoneFormat'
})
export class PhoneFormatPipe implements PipeTransform {

  transform(value: string): string {
    if (!value) return '';
    let formattedValue = '';
    const areaCode = value.slice(0, 3);
    formattedValue += `(${areaCode}) `;
    if (value.length > 3) {
        const firstPart = value.slice(3, 6);
        formattedValue += firstPart;
    }
    if (value.length > 6) {
        formattedValue += '-';
        const secondPart = value.slice(6);
        formattedValue += secondPart;
    }
    return formattedValue;

}

}
