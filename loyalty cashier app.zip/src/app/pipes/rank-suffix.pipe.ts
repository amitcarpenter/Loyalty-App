import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'rankSuffix'
})
export class RankSuffixPipe implements PipeTransform {

   transform(value: number): string {
    const suffixes = ['th', 'st', 'nd', 'rd'];
    const v = value % 100;
    return value + (suffixes[(v - 20) % 10] || suffixes[v] || suffixes[0]);
  }

}
