import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  userInfo: any;
  options = {
    headers: new HttpHeaders({ 'Authorization': '' }),
  };
  httpOptions = {
     headers: new HttpHeaders({
      'Content-Type': 'multipart/form-data',
  }),};
  businessData: any;
  constructor(
    private http: HttpClient, ){}
     getLocalStorageData(data:any){
      const storedData = localStorage.getItem(data);
      return storedData;
     }
     setTheme(){
      const storedData = localStorage.getItem('business_data');
      this.businessData = JSON.parse(storedData);
      if(this.businessData){
        console.log('this.businessData====>',this.businessData)
         console.log('this.businessData======>',this.businessData.data.theme_color)
         const darkColor=this.ColorLuminance(this.businessData.data.theme_color,-0.5)
         const themeWrapper = document.querySelector('body');
         document.documentElement.style.setProperty('--secondary-color', darkColor || '#00308F');
         document.documentElement.style.setProperty('--primary-color', this.businessData.data?.theme_color || '#00308F');
         
      }else{
         console.log('no data found')
      }
    }
    ColorLuminance(hex, lum) {
      hex = String(hex).replace(/[^0-9a-f]/gi, '');
      if (hex.length < 6) {
        hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
      }
      lum = lum || 0;
      var rgb = "#", c, i;
      for (i = 0; i < 3; i++) {
        c = parseInt(hex.substr(i*2,2), 16);
        c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
        rgb += ("00"+c).substr(c.length);
      }
      return rgb;
    }
     getBusinessId(data:any){
      console.log('data',data);
      return this.http.post(`${environment.baseUrl}/customer/businessID`,data);
     }
     login(data:any){
      return this.http.post(`${environment.baseUrl}/cashier/login`,data);
      // return this.http.post(`${environment.baseUrl}/api/cashier/login`,data);
     }
     getuserinfo(data:any){
      return this.http.post(`${environment.baseUrl}/cashier/userinfo`,data);
      // return this.http.post(`${environment.baseUrl}/api/cashier/userinfo`,data);
     }
     signup(data:any){
      return this.http.post(`${environment.baseUrl}/customer/signup`,data);
    }
    customerLogin(data:any){
      return this.http.post(`${environment.baseUrl}/customer/login`, data);
     }
     getReward(data:any){
      return this.http.post(`${environment.baseUrl}/reward/getAll`,data);
    }
    getLoyaltyPoints(data:any){
      return this.http.post(`${environment.baseUrl}/loyalty/getLoyaltyPoints`,data);
    }
    getRedeemLoyaltyPoints(data:any){
      return this.http.post(`${environment.baseUrl}/loyalty/transaction`,data);
    }
    // redeem reward api
    redeemReward(data:any){
      console.log('data',data)
      return this.http.post(`${environment.baseUrl}/reward/redeem`,data);
    }
  }


