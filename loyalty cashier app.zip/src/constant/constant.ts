export const constantKeys={
    businessInfo:"businessInfo",
    connectioninfo:"connectioninfo",
    userinfo:'userinfo',
    user_data:'user_data',
    NEW:'NEW',
    customerProfileinfo:'customerProfileinfo',
    onCall:'OnCall'

}