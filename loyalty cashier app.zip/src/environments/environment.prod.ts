export const environment = {
  production: true,
 
  baseUrl:'https://loyalty-prod.hackerkernel.co/api',
  socketIo:'https://loyalty-prod.hackerkernel.co/',
  // baseUrl:'http://localhost:3003/api',
  // socketIo:'http://localhost:3003',
  imageBaseUrl:'/demo/loyalty-cashier/'
};
