import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';
import { OuterGuard } from './guards/outer.guard';

const routes: Routes = [
 
  {
    path: '',
    redirectTo: 'business-id-page',
    pathMatch: 'full'
  },
  {
    path: 'login',
    // canActivate: [OuterGuard],
    loadChildren: () => import('./pages/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'signup',
  //  canActivate: [OuterGuard],
    loadChildren: () => import('./pages/signup/signup.module').then( m => m.SignupPageModule)
  },
  {
    path: 'code-screen',
    // canActivate: [OuterGuard],
    loadChildren: () => import('./pages/code-screen/code-screen.module').then( m => m.CodeScreenPageModule)
  },
  {
    path: 'welcome-screen',
    // canActivate: [OuterGuard],
    loadChildren: () => import('./pages/welcome-screen/welcome-screen.module').then( m => m.WelcomeScreenPageModule)
  },
  {
    path: 'customer-interface',
    // canActivate: [AuthGuard],
    loadChildren: () => import('./pages/customer-interface/customer-interface.module').then( m => m.CustomerInterfacePageModule)
  },
  {
    path: 'transaction-end',
    // canActivate: [AuthGuard],
    loadChildren: () => import('./pages/transaction-end/transaction-end.module').then( m => m.TransactionEndPageModule)
  },
  {
    path: 'business-id-page',
    // canActivate: [OuterGuard],
    loadChildren: () => import('./pages/business-id-page/business-id-page.module').then( m => m.BusinessIdPagePageModule)
  },
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
