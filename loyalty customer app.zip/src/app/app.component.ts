import { Component } from '@angular/core';
import { register } from 'swiper/element/bundle';
import { ApiService } from './services/api.service';
import { Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { Network } from '@capacitor/network';
import { MessageService } from './services/message.service';
import { constantKeys } from 'src/constant/constant';
import { StorageService } from './services/storage.service';
import { StatusBar, Style } from '@capacitor/status-bar';

register();
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  business_data="business_data";
  userdata="user_data";
  businessData: any;
  businessinfo: any;
  backButton: any;
  
  constructor(private storageservice:StorageService,private message: MessageService,private apiService: ApiService, private router: Router,private platform: Platform) {
   
    Network.addListener('networkStatusChange', status => {
      console.log('Network status changed', status);
      if(status.connected){
       }else{
        this.message.presentToast('You Are Offline', 'danger');
       }
     });
      this.platform.backButton.subscribeWithPriority(0, () => {
      return;
    });
   
      const logCurrentNetworkStatus = async () => {
      const status = await Network.getStatus();
      console.log('Network status:', status);
    };

      this.navigate() 
      StatusBar.hide();
     }
 
  navigate(){
    const storedData =this.apiService.getLocalStorageData(this.business_data);
    this.businessData = JSON.parse(storedData);
    console.log('hello abhi how are you')
    if(this.businessData){
      console.log('this.businessData====>',this.businessData)
      const storedData =this.apiService.getLocalStorageData(this.userdata);
       console.log('this.businessData======>',this.businessData.data.theme_color)
       const darkColor=this.ColorLuminance(this.businessData.data.theme_color,-0.5)
       const themeWrapper = document.querySelector('body');
       document.documentElement.style.setProperty('--secondary-color', darkColor || '#00308F');
       document.documentElement.style.setProperty('--primary-color', this.businessData.data?.theme_color || '#00308F');
       if(this.businessData){
          console.log("businessinfo1",this.businessData)
          this.storageservice.get(constantKeys.connectioninfo).then(data => {
            console.log("businessinfo2", data)
            if (data) {
            console.log("businessinfo hello abhi your data here", data)
            let info = JSON.parse(data);
            if (info) {
              this.businessinfo = info;
              console.log("businessinfo", this.businessinfo)
              if(storedData){
                this.router.navigate(['/customer-interface'])
              }else{
                this.router.navigate(['/login'])
              }
              } else {
              console.log('FALSE')
              }
             }else{
              console.log("businessinfo2 yoour data not here", data)
            this.router.navigate(['/code-screen'])
          }
        });
       } else{
        this.router.navigate(['/code-screen'])
      }
    }else{
      this.router.navigate(['/business-id-page'])
    }
  }
  ColorLuminance(hex, lum) {
    hex = String(hex).replace(/[^0-9a-f]/gi, '');
    if (hex.length < 6) {
      hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
    }
    lum = lum || 0;
    var rgb = "#", c, i;
    for (i = 0; i < 3; i++) {
      c = parseInt(hex.substr(i*2,2), 16);
      c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
      rgb += ("00"+c).substr(c.length);
    }
    return rgb;
  }
  ionViewDidEnter() {
 
    this.backButton = this.platform.backButton.subscribeWithPriority(9999, () => {
      alert('do nothing.');
    });
  }
  ionViewWillLeave() {
    this.backButton.unsubscribe();
  }
}


