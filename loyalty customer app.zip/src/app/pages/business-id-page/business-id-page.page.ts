// import { Component,EventEmitter,OnInit, Output, ViewChild } from '@angular/core';
// import { Router } from '@angular/router';
// import { IonInput, Platform } from '@ionic/angular';
// import { ApiService } from 'src/app/services/api.service';
// import { LoaderService } from 'src/app/services/loader.service';
// import { MessageService } from 'src/app/services/message.service';
// import { StorageService } from 'src/app/services/storage.service';
// import { constantKeys } from 'src/constant/constant';
// import { Keyboard } from '@capacitor/keyboard';
// @Component({
//   selector: 'app-business-id-page',
//   templateUrl: './business-id-page.page.html',
//   styleUrls: ['./business-id-page.page.scss'],
// })
// export class BusinessIdPagePage implements OnInit {
//   @ViewChild('emailInput', { static: true }) emailInput: IonInput;

//   dataChangeEvent: EventEmitter<string> = new EventEmitter<string>();
//   businessId:any;
//   backButton: any;
//   constructor(  private platform: Platform,private router: Router, private apiService: ApiService, private loader: LoaderService,
//     private message: MessageService,
//     private storageservice: StorageService,
//   ) { 
//     Keyboard.show();
//   }

//   ngOnInit() {
//   }
//   addToBusinessId(value: any) {
//     this.businessId += value;
//   }
//   removeLastDigit() {
//     this.businessId = this.businessId.slice(0, -1);
//   }
//   submitBusinessId() {
//     Keyboard.hide();
//     if (!this.businessId) {
//       this.message.presentToast('Enter Business Id', 'danger');
//       return;
//     }
//     const data = {
//       business_id: this.businessId
//     }
//     console.log('Business ID submitted:', this.businessId);
//     try {
//       this.apiService.getBusinessId(data).subscribe((res:any) => {

//         let storageinfo = JSON.stringify(res.data);
//         console.log('storageservice', storageinfo)
//         this.storageservice.set(constantKeys.businessInfo,JSON.stringify(res.data))
//         console.log('storageservice', this.storageservice)
//         localStorage.setItem('business_data', JSON.stringify(res));
//         this.storageservice.set(constantKeys.connectioninfo, res);
//         this.deleteExample(constantKeys.connectioninfo);
//         this.dataChangeEvent.emit(res.data);
//         this.router.navigate(['/code-screen']);
//         // this.router.navigate(['/login']);
//         this.businessId = " ";
//       }, (error) => {
//         this.message.presentToast('Something went wrong', 'danger');
//        })
//     } catch (err) {
//       console.log('we getting some error');
//     }
//    }
//    ionViewDidEnter() {
//      this.emailInput.setFocus();
//       this.backButton = this.platform.backButton.subscribeWithPriority(9999, () => {
//        });
//     }
//     ionViewWillLeave() {
//       this.backButton.unsubscribe();
//     }
//     deleteExample(keyToDelete:any) {
//       // const keyToDelete = 'yourKey';
//       this.storageservice.deleteItem(keyToDelete)
//         .then(() => {
//           console.log(`Item with key ${keyToDelete} deleted successfully.`);
//         })
//         .catch(error => {
//           console.error(`Error deleting item with key ${keyToDelete}:`, error);
//         });
//       }
// }


import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { IonInput, Platform } from '@ionic/angular';
import { ApiService } from 'src/app/services/api.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MessageService } from 'src/app/services/message.service';
import { StorageService } from 'src/app/services/storage.service';
import { constantKeys } from 'src/constant/constant';
import { Keyboard } from '@capacitor/keyboard';




@Component({
  selector: 'app-business-id-page',
  templateUrl: './business-id-page.page.html',
  styleUrls: ['./business-id-page.page.scss'],
})
export class BusinessIdPagePage implements OnInit {
  @ViewChild('emailInput', { static: true }) emailInput: IonInput;

  @Output() dataChangeEvent: EventEmitter<any> = new EventEmitter<any>();
  businessId: string = ''; // Initialize businessId as string
  backButton: any;

  constructor(
    private platform: Platform,
    private router: Router,
    private apiService: ApiService,
    private loader: LoaderService,
    private message: MessageService,
    private storageservice: StorageService,
  ) { }

  ngOnInit() { }

  addToBusinessId(value: any) {
    this.businessId += value.toString(); // Convert value to string before appending
  }

  removeLastDigit() {
    this.businessId = this.businessId.slice(0, -1);
  }

  submitBusinessId() {

    Keyboard.hide();
    if (!this.businessId.trim()) {
      this.message.presentToast('Enter Business Id', 'danger');
      return;
    }
    const data = {
      business_id: this.businessId
    };
    this.loader.show();
    this.apiService.getBusinessId(data).subscribe(
       (res: any) => {
        this.loader.dismiss();
         console.log('Business ID submitted:', this.businessId);
        this.storageservice.set(constantKeys.businessInfo, JSON.stringify(res.data));
        localStorage.setItem('business_data', JSON.stringify(res));
        this.storageservice.set(constantKeys.connectioninfo, res);
        this.deleteExample(constantKeys.connectioninfo);
        this.dataChangeEvent.emit(res.data);
        this.loader.dismiss();
        this.router.navigate(['/code-screen']);
        this.businessId = ''; // Reset businessId after submission
       
      },
      (error) => {
        this.loader.dismiss();
        this.message.presentToast('Something went wrong', 'danger');
      }
    );
  }

  ionViewDidEnter() {
    this.emailInput.setFocus();
    this.backButton = this.platform.backButton.subscribeWithPriority(9999, () => { });
  }

  ionViewWillLeave() {
    this.backButton.unsubscribe();
  }

  deleteExample(keyToDelete: string) {
    this.storageservice.deleteItem(keyToDelete)
      .then(() => {
        console.log(`Item with key ${keyToDelete} deleted successfully.`);
      })
      .catch(error => {
        console.error(`Error deleting item with key ${keyToDelete}:`, error);
      });
  }
}
