import { Component, OnInit, OnDestroy } from '@angular/core';
import { StorageService } from 'src/app/services/storage.service';
import { constantKeys } from 'src/constant/constant';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { Platform } from '@ionic/angular';
import { SocketIoService } from 'src/app/services/socket-io.service';

@Component({
  selector: 'app-code-screen',
  templateUrl: './code-screen.page.html',
  styleUrls: ['./code-screen.page.scss'],
})
export class CodeScreenPage implements OnInit, OnDestroy {
  businessDataObject: any;
  businessinfo: any;
  intervalId: any;

  randomNumbers: number[] = [];
  arraySize: number = 5;
  unique: any
  Connectioninfo: any;
  connectionStatus = false;
  backButton: any;
  connectionData: any;
  start_connection = 'start_connection';
  recBussnessResponse: any;
  connectionReadyInitialized: boolean = false;
  constructor(
    private storageservice: StorageService,
    private router: Router,
    private activeroute: ActivatedRoute,
    private apiService: ApiService,
    private platform: Platform,
    private SocketIoService: SocketIoService,
  ) {
    this.apiService.setTheme();
    const storedData = localStorage.getItem('business_data');
    this.businessDataObject = JSON.parse(storedData);
    }

ionViewWillEnter(){
    this.activeroute.url.subscribe(url => {
    this.SocketIoService.receiveBussnessResponse$.next('');
    this.SocketIoService.instruction$.next('');
    this.randomNumbers = [];
    this.getConnectionInfo();
    this.getStorageinfo();
    setTimeout(()=>{
      this.getStorageinfo();
    },2000);
    this.randomCreate();
    this.intervalId=setInterval(()=>{
      this.SocketIoService.receiveBussnessResponse$.next('');
      this.SocketIoService.instruction$.next('');
      this.randomNumbers = [];
      this.randomCreate();
      this.getStorageinfo();
      },180000);
  });
}

  async ngOnInit() {
    
    // this.activeroute.url.subscribe(url => {
    //     this.SocketIoService.receiveBussnessResponse$.next('');
    //     this.SocketIoService.instruction$.next('');
    //     this.randomNumbers = [];
    //     this.getConnectionInfo();
    //     this.getStorageinfo();
    //     this.randomCreate();
    //     this.intervalId=setInterval(()=>{
    //       this.SocketIoService.receiveBussnessResponse$.next('');
    //       this.SocketIoService.instruction$.next('');
    //       this.randomNumbers = [];
    //       this.randomCreate();
    //       this.getStorageinfo();
    //       },180000);
    //   });
  }
  ngOnDestroy() {
      if (this.intervalId) {
         clearInterval(this.intervalId);
       }
       this.unique='';
      }

  getStorageinfo() {
    this.storageservice.get(constantKeys.businessInfo).then(async data => {
      if (data) {
        let info = JSON.parse(data);
        if (info) {
          this.businessinfo = info;
          let details = {
            bussnessId: this.businessinfo.business_id,
            unique: this.unique,
            org_id: info.id
          }
          if (this.Connectioninfo && this.Connectioninfo.status == "1") {
            this.router.navigate(['/login']);
            this.SocketIoService.sendSocketMessage(this.start_connection, details)
             }
          else {
            this.SocketIoService.sendSocketMessage(this.start_connection, details)
          }
          this.SocketIoService.receiveBussnessResponse(`receive_Bussness_Response${this.unique}`)
            this.SocketIoService.receiveBussnessResponse$.subscribe((res: any) => {
              if (res) {
                let info = res
                if (info && info.status == 1) {
                  info = JSON.stringify(info);
                  this.storageservice.set(constantKeys.connectioninfo, info);
                  this.router.navigate(['/login']);
                }
              }
              else {
              
              }
            });
          this.SocketIoService.connectionready(`connection_ready_${this.unique}`)
          this.connectionData = this.SocketIoService.connectionready$.subscribe((message: any) => {
            if (message) {
              if (message && message.conection) {
                console.log('hello abhi how are,,,,,,,,')
                this.connectionStatus = true;
                let info = message;
                this.Connectioninfo = message;
              } else {
                console.log('hello abhi how are you not are you,,,,,')
                this.connectionStatus = false;
              }
            }
          });
        } else {
          // this.router.navigate(['/business-id-page'])
        }
      } else {
        // this.router.navigate(['/business-id-page']);
      }
    });
  }

  getConnectionInfo() {
    if(constantKeys.connectioninfo){
      console.log('not data',constantKeys.connectioninfo)
      this.storageservice.get(constantKeys.connectioninfo).then(data => {
        if (data) {
           let info = JSON.parse(data);
          this.Connectioninfo = info
         
        }
      })
    }else{
     console.log('not data')
    }
  
  }
  async deleteExample(keyToDelete: any) {
    // const keyToDelete = 'yourKey';
    await this.storageservice.deleteItem(keyToDelete).then(() => {
      }).catch((err) => {
      console.log("debug2");
      console.log(err);
    })
  }
  randomCreate() {
    for (let i = 0; i < 4; i++) {
      this.arraySize = Math.floor(Math.random() * 10);
      this.randomNumbers.push(this.arraySize);
    }

    const resultWithoutHyphens = this.randomNumbers.join('');
    this.unique = resultWithoutHyphens;
  }
  ionViewDidEnter() {
    // this.randomCreate();
    this.backButton = this.platform.backButton.subscribeWithPriority(9999, () => {

    });
  }
  ionViewWillLeave() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
    this.unique='';
   }
 }

