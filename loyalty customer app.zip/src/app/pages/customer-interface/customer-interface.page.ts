import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { Swiper } from 'swiper';
import { LoaderService } from 'src/app/services/loader.service';
import { StorageService } from 'src/app/services/storage.service';
import { constantKeys } from 'src/constant/constant';
import { environment } from 'src/environments/environment';
import { NavController, ToastController } from '@ionic/angular';
import { MessageService } from 'src/app/services/message.service';

import { Subject, takeUntil } from 'rxjs';
import { RankSuffixPipe } from '../../pipes/rank-suffix.pipe';


@Component({
  selector: 'app-customer-interface',
  templateUrl: './customer-interface.page.html',
  styleUrls: ['./customer-interface.page.scss'],
})
export class CustomerInterfacePage implements OnInit {
  @ViewChild('swiper')
  swiperRef: ElementRef | undefined;
  swiper?: Swiper;
  userData: any;
  user_data = "user_data";
  activeIndex: number = 0;
  public message: string = '';
  bussnessId: any = "";
  selectedOffer: any;
  selectedOfferData: any;
  confirmItem: boolean = false;
  connectioninfo: any;
  businessInfo: any
  userinfo: any
  rewardinfo: any
  loyaltypoints: number;
  Prev: number = 1;
  next: number = 1;
  environment = environment;
  userName: string;
  auto: any;
  bussnessData: any;
  sendBussnessId = 'sendBussnessId';
  ionicmessage = 'ionic-message';
  sendBussnessResponse = 'sendBussnessResponse';
  checkConnectionCode = 'checkConnectionCode';
  socket: any;
  instruction: any;
  private unsubscribe$ = new Subject<void>();
  constructor(
    private loader: LoaderService,
    private router: Router,
    private apiService: ApiService,
    private storageservice: StorageService,
    private activeroute: ActivatedRoute,
    private toastController: ToastController,
    private MessageService: MessageService,

  ) {
    this.apiService.setTheme();
    const storedData = this.apiService.getLocalStorageData(this.user_data);
    this.userData = JSON.parse(storedData);
    const business_data = this.apiService.getLocalStorageData('business_data');
    this.bussnessData = JSON.parse(business_data);
    console.log(this.userData)
    this.userData.data.customerDetails.name = this.UserNameFormat(this.userData.data.customerDetails.name)


  }
  ngOnInit() {

  }

  ionViewWillEnter() {
    this.activeroute.url.subscribe(url => {

      const storedData = this.apiService.getLocalStorageData(this.user_data);
      this.userData = JSON.parse(storedData);
      console.log('Navigated to page from route:', url);
      if (this.userData) {
        this.getStorageinfo('businessInfo');
        this.getStorageinfo('connectioninfo');
        this.getStorageinfo('userinfo');
      } else {
        console.log('datanot found')
      }
    });
  }
  navigatewellcome() {
    this.router.navigate(['/welcome-screen'])
  }
  sendMessage() {
    this.message = '';
  }
  selectOffer(i: any) {
    this.confirmItem = false;

    this.selectedOffer = i.id;
    this.selectedOfferData = i

    let info = {
      bussnessId: this.bussnessId,
      item: i.id,
      userId: `${this.userinfo && this.userinfo.customerDetails ? this.userinfo.customerDetails.id : ''}`,
      confimMs: `${this.selectedOfferData && this.selectedOfferData.title ? this.selectedOfferData.title : ''} Selected By ${this.userinfo && this.userinfo.customerDetails ? this.UserNameFormat(this.userinfo.customerDetails.name) : ''}`,
    }
  }
  deleteExample(keyToDelete: any) {
    this.storageservice.deleteItem(keyToDelete)
      .then(() => {
        console.log(`Item with key ${keyToDelete} deleted successfully.`);
      })
      .catch(error => {
        console.error(`Error deleting item with key ${keyToDelete}:`, error);
      });
  }

  ngOnDestroy() {

  }

  ionViewDidLeave() {

  }
  ionViewWillLeave() {
    if (this.swiper) {
      this.swiper.destroy(true, true);
    }
    console.log('subscribe====>', this.unsubscribe$)
    console.log('subscribe====>', this.unsubscribe$)
  }
  getStorageinfo(key: any) {

    console.log('key', `${key && key === constantKeys.connectioninfo ? constantKeys.connectioninfo : key === constantKeys.userinfo ? constantKeys.userinfo : constantKeys.businessInfo}`);
    this.storageservice.get(`${key && key === constantKeys.connectioninfo ? constantKeys.connectioninfo : key === constantKeys.userinfo ? constantKeys.userinfo : constantKeys.businessInfo}`).then(data => {
      if (data) {
        let info = JSON.parse(data);
        if (info) {

          if (key == constantKeys.connectioninfo) {

            this.connectioninfo = info
            console.log(this.connectioninfo);

           console.log(info);
            this.bussnessId = info.code;
            console.log(constantKeys.connectioninfo, this.connectioninfo);
          }
          else if (key == constantKeys.businessInfo) {
            this.businessInfo = info
            this.getRewardFun(this.businessInfo.id);
            console.log(constantKeys.businessInfo, this.businessInfo)
          } else if (key == constantKeys.userinfo) {
            this.userinfo = info
            console.log(`${key && key === constantKeys.connectioninfo ? constantKeys.connectioninfo : key === constantKeys.userinfo ? constantKeys.userinfo : constantKeys.businessInfo}`);
            console.log(constantKeys.userinfo, this.userinfo)
            this.selectedOfferData = ''
            this.selectedOffer = ''
            this.confirmItem = false
          }
         } else {
          console.log('FALSE')
        }
      }
    });
  }
  NotNowFun() {
    let info = {
      bussnessId: this.bussnessId,
      item: 0,
      userId: `${this.userinfo && this.userinfo.customerDetails ? this.userinfo.customerDetails.id : ''}`,
      endtransaction: true
    }
   setTimeout(() => {
      this.router.navigateByUrl('/transaction-end')
    }, 800);
    console.log('NOT NOW');
    this.loyaltypoints = null;
    this.userData.data = " ";
    localStorage.removeItem('user_data');

    this.deleteExample(constantKeys.userinfo);
  }
  getRewardFun(id: any) {
    let data = {
      'organization_id': id
    }
    console.log('data====abhi verm,', data.organization_id)
    this.apiService.getReward(data).subscribe((reward: any) => {
      if (reward && reward.data) {

        this.rewardinfo = reward.data;
      } else {
        console.log('NO DATA FOUND FOR REWARD')
      }
    }, (error => {
      console.log('error', error);
    }))
  }

  redeemRewardFun() {
    if (!this.selectedOffer) {
      this.MessageService.presentToast('Please Select Offer', 'danger', 'top');
      return
    }
    console.log('selectedOffer', this.selectedOffer, 'selectedOffer Title', this.selectedOfferData.title);
    let info = {
      bussnessId: this.bussnessId,
      item: this.selectedOffer,
      userId: `${this.userinfo && this.userinfo.customerDetails ? this.userinfo.customerDetails.id : ''}`,
      confimMs: `${this.selectedOfferData && this.selectedOfferData.title ? this.selectedOfferData.title : ''} Confirm Item By ${this.userinfo && this.userinfo.customerDetails ? this.UserNameFormat(this.userinfo.customerDetails.name) : ''}`,
      confirmItem: true,
      customerPoints: this.userinfo && this.userinfo.customerDetails && this.userinfo.customerDetails.total_loyalty_point ? this.userinfo.customerDetails.total_loyalty_point : 0
    }
    if (this.userinfo.customerDetails.id) {
      if (this.userinfo.customerDetails.total_loyalty_point && this.userinfo.customerDetails.total_loyalty_point != 0 && this.selectedOfferData && this.selectedOfferData.loyalty_point <= this.userinfo.customerDetails.total_loyalty_point && this.selectedOffer) {
        this.confirmItem = true
        this.MessageService.presentToast('Offer Selected Successfully', 'success', 'top');

      } else {
        info.confirmItem = false
        info.confimMs = `Customer ${this.UserNameFormat(this.userinfo.customerDetails.name)} don't have enough loyalty points to redeem this award: total  loyalty points available is ${this.userinfo.customerDetails.total_loyalty_point}`;
        this.MessageService.presentToast(`So close! You’re only ${this.selectedOfferData.loyalty_point - this.userinfo.customerDetails.total_loyalty_point} points away from redeeming this reward.`, 'danger', 'top')
      }
    } else {
      console.log('this.userinfo.customerDetails.id is NULL MEANS USER DATA IS EMPTY', this.userinfo.customerDetails.id)
    }
  }
  updateuserinfo() {
    let data = {
      userId: this.userinfo.customerDetails.id.toString(),
      organization_id: this.bussnessData.data.id
    }
    this.apiService.getuserinfo(data).subscribe((userinfo: any) => {
      if (userinfo && userinfo.data) {
        this.userinfo.customerDetails.total_loyalty_point = userinfo.data.total_loyalty_point;
        this.storageservice.set(constantKeys.userinfo, this.userinfo);
      }
    }, (error => {
      console.log('error', error)
    }))
  }
  goPrev() {
    console.log('swiper.activeIndex', this.swiper?.activeIndex);
    this.swiper?.slidePrev();

    let info = {
      bussnessId: this.bussnessId,
      item: this.selectedOffer ? this.selectedOffer : 0,
      userId: `${this.userinfo && this.userinfo.customerDetails ? this.userinfo.customerDetails.id : ''}`,
      tab: this.swiper?.activeIndex
    }

  }
  navigateWelcome() {
    this.router.navigate(['/welcome-screen']);
  }
  goNext() {
    this.swiper.slideNext();


    this.activeIndex = this.swiper?.activeIndex;
    console.log('this.activeIndex===>11', this.activeIndex)
    console.log('swiper.activeIndex', this.swiper?.activeIndex);
    let info = {
      bussnessId: this.bussnessId,
      item: this.selectedOffer ? this.selectedOffer : 0,
      userId: `${this.userinfo && this.userinfo.customerDetails ? this.userinfo.customerDetails.id : ''}`,
      tab: this.swiper?.activeIndex
    }

  }
  swiperReady() {

    this.swiper = this.swiperRef?.nativeElement.swiper;

  }
  swiperSlideChanged(e: any) {
    let info = {
      bussnessId: this.bussnessId,
      item: this.selectedOffer ? this.selectedOffer : 0,
      userId: `${this.userinfo && this.userinfo.customerDetails ? this.userinfo.customerDetails.id : ''}`,
      tab: this.swiper?.activeIndex
    }
  }
  async presentToast(confimMs: string) {
    const toast = await this.toastController.create({
      message: confimMs,
      duration: 4000,
      position: 'top',
      cssClass: 'my-custom-class'
    });

    await toast.present();
  }
  UserNameFormat(userName: string) {
    let originalString = userName;
    let words = originalString.split(" ");
    let capitalizedWords = words.map(word => word.charAt(0).toUpperCase() + word.slice(1));
    this.userName = capitalizedWords.join(" ");

    return this.userName
  }
  initSwiper() {
    this.swiper = new Swiper(this.swiperRef?.nativeElement, {
      loop: true,
      breakpoints: {
        700: {
          slidesPerView: 1,
        },
        900: {
          slidesPerView: 3,
        },
        1200: {
          slidesPerView: 4,
        },
      },
    });

  }
}




