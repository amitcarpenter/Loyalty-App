import { Component, OnInit, importProvidersFrom } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MessageService } from 'src/app/services/message.service';
import { StorageService } from 'src/app/services/storage.service';
import { constantKeys } from 'src/constant/constant';

import { environment } from 'src/environments/environment';
import { NavController, Platform } from '@ionic/angular';
import { Keyboard } from '@capacitor/keyboard';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  number: string = '';
  clickedStates: boolean[] = Array(10).fill(false);
  businessData: any;
  business_data = "business_data";
  organization_id: string = '';
  Connectioninfo: any;
  uniquecode: any
  environment = environment;
  backButton: any;
  control: any;
  sendBussnessResponse = 'sendBussnessResponse';
  instruction: any;
  info: any;
  constructor(private router: Router, private apiService: ApiService,
    private loader: LoaderService,

    private message: MessageService,
    private storageservice: StorageService,
    private activeroute: ActivatedRoute,
    private platform: Platform,
    private navCtrl: NavController
  ) {

    this.apiService.setTheme();
    Keyboard.hide();
    const storedData = this.apiService.getLocalStorageData(this.business_data);
    this.businessData = JSON.parse(storedData);
    this.organization_id = this.businessData.data.id;

  }

  ngOnInit() {
    // this.getConnectionInfo();
  }

  ionViewWillEnter() {
    this.activeroute.url.subscribe(url => {
      console.log('Navigated to page from route:', url);
      this.number = ''
      
    });
  }
  navigatewellcome() {
    this.router.navigate(['/welcome-screen'])
  }
  addToBusinessId(value: any) {
    this.clickedStates[value] = !this.clickedStates[value];
    setTimeout(() => {
      this.clickedStates[value] = !this.clickedStates[value];
    }, 300)
    if ((this.number + value).length <= 10) {
      this.number += value;
    } else {
      this.message.presentToast('You can Enter only 10 digit', 'danger')
    }
  }
  removeLastDigit() {
    this.number = this.number.slice(0, -1);
  }
  submit() {
    if (!this.number) {
      this.message.presentToast('Please Enter Your Mobile number', 'danger');
      return
    }
    if ((this.number).length < 10) {
      this.message.presentToast('Please enter 10 digit', 'danger')
      return
    }
    const data = {
      contact_number: this.number,
      organization_id: this.organization_id.toString()
    }
    this.loader.show();
    console.log('Business ID submitted:', this.number);
    try {
      this.apiService.login(data).subscribe((res: any) => {
        console.log('ressssss=>', res)
        this.loader.dismiss();
        if (res.data.userType == 'NEW') {
          this.loader.dismiss();
          localStorage.setItem(constantKeys.contact_info, JSON.stringify(data));
          this.number = " ";
          this.router.navigate(['/signup'], { queryParams: { number: this.number } });
        } else {
          this.loader.dismiss();
          this.message.presentToast(res.message, 'success');
          console.log('login res', res)
          let userinfo = JSON.stringify(res.data)
          this.storageservice.set(constantKeys.userinfo, userinfo);
          this.info = {
            bussnessId: this.Connectioninfo.code,
            userId: `${res && res.data.customerDetails ? res.data.customerDetails.id : ''}`,
            customerLogin: true,
            ms: 'user ne login kiya'
          }

          localStorage.setItem('user_data', JSON.stringify(res));
          this.router.navigate(['/welcome-screen'])
          this.number = " ";
          this.info = " ";
        }
      },
        (error) => {
          if (error) {
            this.message.presentToast('Incorrect Number', 'danger');
            this.loader.dismiss();
          }

        }
      )
    }
    catch (err) {
      this.loader.dismiss();
      console.log('we getting some error');
    }
  }
  ngOnDestroy() {

  }

  deleteExample(keyToDelete: any) {
    this.storageservice.deleteItem(keyToDelete)
      .then(() => {
        console.log(`Item with key ${keyToDelete} deleted successfully.`);
      })
      .catch(error => {
        console.error(`Error deleting item with key ${keyToDelete}:`, error);
      });
  }
  ionViewDidEnter() {
    this.backButton = this.platform.backButton.subscribeWithPriority(9999, () => {
    });
  }
  ionViewWillLeave() {
    this.backButton.unsubscribe();
  }
}


