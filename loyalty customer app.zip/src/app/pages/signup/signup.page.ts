import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MessageService } from 'src/app/services/message.service';
import { ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';
import { constantKeys } from 'src/constant/constant';
import { StorageService } from 'src/app/services/storage.service';
import { IonInput, IonModal, Platform } from '@ionic/angular';
import { Keyboard } from '@capacitor/keyboard';

import { IonDatetime } from '@ionic/angular';
import * as moment from 'moment';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
})
export class SignupPage implements OnInit {
  @ViewChild('emailInput', { static: true }) emailInput: IonInput;
  @ViewChild(IonModal) modal: IonModal;

  /**
  * How the date should be displayed on the page. Default 'DD/MM/YYYY'
  */
  @Input() public displayFormat: string = 'DD/MM/YYYY';

  /**
  * The value of the component
  */
  @Input() public date: string;

  public isModalOpen = false;
  public onTouched: () => void;
  public propagateChange: (_: any) => void;
  business_data = "business_data";
  businessData: any;
  contact_info: any;
  
  name: any;
  number: any;
  organization_id: any;
  environment=environment;
  backButton: any;
  username: any;

  uniquecode:any
  Connectioninfo: any;
  sendBussnessResponse='sendBussnessResponse';
  instruction: any;
  datePickerOptions:any;
 
  constructor(private apiService: ApiService, private fb: FormBuilder, private router: Router,
    private loader: LoaderService,
    private route: ActivatedRoute,

    private message: MessageService,
    private storageservice: StorageService,
    private platform: Platform,
 
  
  ) {
    this.apiService.setTheme();
    Keyboard.show();
    const storedData = this.apiService.getLocalStorageData(this.business_data);
     this.businessData = JSON.parse(storedData);
    this.organization_id=this.businessData.data.id;
    const contact_info = this.apiService.getLocalStorageData(constantKeys.contact_info);
    this.businessData = JSON.parse(storedData);
    this.contact_info = JSON.parse(contact_info);
    this.organization_id = this.businessData.data.id;
    console.log('dateValue==>',this.dateValue)
  }
 
  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.number = params['number'];
      console.log(this.number);
    });
    this.getConnectionInfo()
  }
onInputChange(event: any) {
    console.log('event abhu=====>',event) 
    if (event && event.key === "Enter") { 
       console.log('event=====>',event) 
       event.preventDefault(); 
       this.onSubmit(); 
    }
  }

  onSubmit() {
    if (!this.name) {
      this.message.presentToast('Name is  required', 'danger');
     } else {
      this.username = this.name.split(' '); 
      for (let i = 0; i < this.username.length; i++) {
          this.username[i] = this.username[i].charAt(0).toUpperCase() + this.username[i].slice(1); 
      }
      let capitalizedString = this.username.join(' '); 
      this.loader.show();  
      try {
        var dateObject = new Date(this.date);
        var day = dateObject.getDate();
        var month = dateObject.getMonth() + 1;
        var year = dateObject.getFullYear();
        const dob = `${day}/${month}/${year}`;
        const data = {
          username: capitalizedString,
          dob: dob,
          contact_number: this.contact_info.contact_number,
          organization_id: this.organization_id.toString()
          };
          this.apiService.signup(data).subscribe((res:any) => {
          this.loader.dismiss();  
          localStorage.removeItem(constantKeys.contact_info);
          let userinfo = JSON.stringify(res.data)
          this.storageservice.set(constantKeys.userinfo,userinfo);
          localStorage.setItem('user_data', JSON.stringify(res));
           let info={
            bussnessId:this.Connectioninfo.code,
            userId:`${res && res.data.customerDetails ? res.data.customerDetails.id :''}`,
            customerLogin:true,
            ms:'user ne login kiya'
          }
        
          this.loader.dismiss(); 
          this.router.navigate(['/welcome-screen']);
          this.name = "";
          this.date = "";
        }, (error) => {
          this.message.presentToast('Something went wrong', 'danger');
        });
      } catch (err) {
        this.loader.dismiss(); 
        this.message.presentToast('Something went wrong', 'danger');
      }
    }
  }
  getMinDate(): string {
    const today = new Date();
    const minDate = today.toISOString().substr(0, 10);
    return minDate;
  }
  ngOnDestroy() {
    console.log('helllo abhi how are you leave this page1',this.instruction);
    // this.instruction.unsubscribe();
    console.log('helllo abhi how are you leave this page2',this.instruction);
  
  }
  getConnectionInfo()
  {
    this.storageservice.get(constantKeys.connectioninfo).then(data => {
      if (data) {
        console.log('data',data)
        let info = JSON.parse(data);
        this.Connectioninfo=info
        this.uniquecode=info.code;
        console.log('connectioninfo--',info);
        
      }
    })
  }
  ionViewDidEnter() {
    this.emailInput.setFocus();
    this.backButton = this.platform.backButton.subscribeWithPriority(9999, () => {
     });
  }ionViewWillLeave() {
      this.backButton.unsubscribe();
    }
    deleteExample(keyToDelete:any) {
      // const keyToDelete = 'yourKey';
      this.storageservice.deleteItem(keyToDelete)
        .then(() => {
          console.log(`Item with key ${keyToDelete} deleted successfully.`);
        })
        .catch(error => {
          console.error(`Error deleting item with key ${keyToDelete}:`, error);
        });
      }
   public get dateValue() {
       console.log('date ==>',this.date)
        return this.date;
    }

    public set dateValue(val: string) {
         this.date = moment(val).format('YYYY-MM-DD');
         console.log('dateValue==>', this.date)
        this.propagateChange(this.date);
    }

    public writeValue(value: any) {
        if (value !== undefined) {
            this.date = value;
        }
    }

    public registerOnChange(fn) {
        this.propagateChange = fn;
    }

    public registerOnTouched(fn) {
        this.onTouched = fn;
    }

    public openModal() {
        this.isModalOpen = true;
    }

    public handleDismiss() {
        this.isModalOpen = false;
    }

    /**
     * Returns a string formatted in the component's display format
     *
     * @param date the date to format
     */
    public getFormattedDateDisplay(date: string): string {
     
        if (!date) {
            return '';
        }

        return moment(date).format(this.displayFormat);
    }
}
