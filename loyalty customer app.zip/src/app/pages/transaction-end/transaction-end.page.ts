import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { ApiService } from 'src/app/services/api.service';
import { StorageService } from 'src/app/services/storage.service';
import { constantKeys } from 'src/constant/constant';
import { SocketIoService } from 'src/app/services/socket-io.service';
@Component({
  selector: 'app-transaction-end',
  templateUrl: './transaction-end.page.html',
  styleUrls: ['./transaction-end.page.scss'],
})
export class TransactionEndPage implements OnInit {
  backButton: any;
  sendBussnessResponse = 'sendBussnessResponse';
  constructor(private storageservice: StorageService,private router:Router, private platform: Platform,private apiService:ApiService,private SocketIoService:SocketIoService) {
    this.apiService.setTheme();
    let info={};
    this.SocketIoService.sendSocketMessage(this.sendBussnessResponse, info)
     setTimeout(()=>{
      this.router.navigate(['/login'])
      localStorage.removeItem('user_data');
      this.deleteExample(constantKeys.userinfo);
     },2000)
   }
   deleteExample(keyToDelete: any) {
    this.storageservice.deleteItem(keyToDelete)
      .then(() => {
        console.log(`Item with key ${keyToDelete} deleted successfully.`);
      })
      .catch(error => {
        console.error(`Error deleting item with key ${keyToDelete}:`, error);
      });
  }
   ngOnInit() {
    }
    ionViewDidEnter() {
          this.backButton = this.platform.backButton.subscribeWithPriority(9999, () => {
         });
      }
      ionViewWillLeave() {
        this.backButton.unsubscribe();
      }
}
