// import { Injectable } from '@angular/core';
// import { io, Socket } from "socket.io-client";
// import { BehaviorSubject, Observable } from 'rxjs';
// import { environment } from 'src/environments/environment';

// @Injectable({
//   providedIn: 'root'
// })
// export class SocketIoService {
//   private socket: Socket;
//   newMessageReceived$: BehaviorSubject<any | null> = new BehaviorSubject<any | null>(null);

//   constructor() {
//     this.socket = io(environment.socketIo);
//   }

//   subscribeToSocketMessages(event: string): void {
//     // Unsubscribe from the event to avoid duplicate subscriptions
//     this.socket.off(event);

//     // Subscribe to the event to receive messages
//     this.socket.on(event, (message) => {
//       console.log('Received message:', message);
//       this.newMessageReceived$.next(message);
//     });
//   }

//   public sendSocketMessage(connection: string, message: any): void {
//     console.log('Sending message:', message);
//     this.socket.emit(connection, message);
//   }

//   public getNewMessages(): Observable<any | null> {
//     return this.newMessageReceived$.asObservable();
//   }
// }



// import { Injectable } from '@angular/core';
// import { io, Socket } from "socket.io-client";
// import { BehaviorSubject, Observable } from 'rxjs';
// import { environment } from 'src/environments/environment';

// @Injectable({
//   providedIn: 'root'
// })
// export class SocketIoService {
//   counter = 0;
//   private socket: Socket;
//   newMessageReceived$: BehaviorSubject<any | null> = new BehaviorSubject<any | null>(null);

//   constructor() {
//     this.socket = io(environment.socketIo);
//   }

//   subscribeToSocketMessages(event): void {
//     console.log("Event name " + event);
    
//     this.socket.on(event, (message) => {
//       console.log('this.socket.off(event);=====>', this.counter++)
//       this.newMessageReceived$.next(message);
//       console.log('this.socket.off(event);=====>', this.newMessageReceived$)
//     });

//   }
//   public sendSocketMessage(connection: string, message: any): void {
//     console.log('Sending message: ', message);
//     // this.socket.off(connection, message);
//     this.socket.emit(connection, message);
//   }

// }



import { Injectable } from '@angular/core';
import { io, Socket } from "socket.io-client";
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SocketIoService {
  private socket: Socket;
  isSubscribed = false;
  newMessageReceived$: BehaviorSubject<any | null> = new BehaviorSubject<any | null>(null);
  receiveBussnessResponse$: BehaviorSubject<any | null> = new BehaviorSubject<any | null>(null);
  instruction$: BehaviorSubject<any | null> = new BehaviorSubject<any | null>(null);
  connectionready$: BehaviorSubject<any | null> = new BehaviorSubject<any | null>(null);
  counter = 0;
  constructor() {
    this.socket = io(environment.socketIo);
  }
  connectionready(event: string): void {
    this.socket.off(event).on(event, (message) => {
      console.log('this.socket.off(event);=====>', this.counter++)
      this.connectionready$.next(message);
      console.log('this.socket.off(event);=====>', this.newMessageReceived$)
    });
  }
  receiveBussnessResponse(event: string): void {
 
    this.socket.off(event).on(event, (message) => {
      console.log("sss-----times");
      console.log(event);
      console.log('this.socket.off(event);=====>', this.counter++)
      this.receiveBussnessResponse$.next(message);
      console.log('this.socket.off(event);=====>', this.newMessageReceived$)
    });
  }
  instruction(event: string): void {
   
    // this.socket.off(event);
    this.socket.off(event).on(event, (message) => {
      console.log("event is ");
      this.instruction$.next(message);
     });
   console.log(' this.instruction$.next(message);==>',this.instruction$)
  }
  public sendSocketMessage(connection: string, message: any): void {
    console.log('Sending message: ', message);
    this.socket.off(connection, message).emit(connection, message);
  }
  offevent(event){
    this.socket.off(event);
  }
}
