export const constantKeys={
    businessInfo:"businessInfo",
    connectioninfo:"connectioninfo",
    userinfo:'userinfo',
    NEW:'NEW',
    business_data:'business_data',
    contact_info:'contact_info'

}